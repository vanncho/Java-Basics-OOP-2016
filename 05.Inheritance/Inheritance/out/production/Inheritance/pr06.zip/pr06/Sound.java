package pr06;

public interface Sound {

    String produceSound();
}
